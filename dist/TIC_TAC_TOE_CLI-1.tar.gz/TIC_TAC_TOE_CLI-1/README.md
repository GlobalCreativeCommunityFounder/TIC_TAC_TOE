# TIC_TAC_TOE_CLI

"Tic Tac Toe" game running on command line interface where the player plays as 
crosses ('X's) and the opponent plays as circles ('O's).

# Executable File

The executable file is downloadable at https://github.com/GlobalCreativeCommunityFounder/TIC_TAC_TOE/blob/master/TIC_TAC_TOE_CLI/dist/tic_tac_toe/tic_tac_toe.exe.